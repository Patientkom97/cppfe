<?php
declare(strict_types=1);

date_default_timezone_set('Africa/Kinshasa');

define('ROOT', dirname(__DIR__));
// Sur Vercel, seul /tmp est inscriptible (et il est vidé régulièrement : usage de démonstration uniquement)
$onVercel = getenv('VERCEL') !== false;
define('DB_PATH', ($onVercel ? '/tmp' : ROOT . '/data') . '/cppf.sqlite');
define('UPLOAD_DIR', $onVercel ? '/tmp/uploads' : ROOT . '/uploads');

// Chemin du site (fonctionne à la racine ou dans un sous-dossier)
$dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$dir = preg_replace('#/(admin|api)$#', '', $dir);
define('BASE_URL', $dir);

// Rubriques acceptées par le formulaire de contact
const SUBJECTS = ['Demande d’aide', 'Partenariat', 'Devenir bénévole', 'Autre'];
